import { mapDefined } from '@atproto/common'
import type { AtUriString, DidString } from '@atproto/lex'
import { InvalidRequestError, type Server } from '@atproto/xrpc-server'
import type { AppContext } from '../../../../context.js'
import type {
  HydrateCtxWithViewer,
  Hydrator,
} from '../../../../hydration/hydrator.js'
import { parseString } from '../../../../hydration/util.js'
import { app } from '../../../../lexicons/index.js'
import {
  type HydrationFnInput,
  type PresentationFnInput,
  type RulesFnInput,
  type SkeletonFnInput,
  createPipeline,
} from '../../../../pipeline.js'
import type { Views } from '../../../../views/index.js'
import { clearlyBadCursor, fillPage, resHeaders } from '../../../util.js'

const CURATELIST = app.bsky.graph.defs.curatelist.value
const MODLIST = app.bsky.graph.defs.modlist.value

export default function (server: Server, ctx: AppContext) {
  const getListsWithMembership = createPipeline(
    skeleton,
    hydration,
    filterPurposes,
    presentation,
  )
  server.add(app.bsky.graph.getListsWithMembership, {
    auth: ctx.authVerifier.standard,
    handler: async ({ params, auth, req }) => {
      const viewer = auth.credentials.iss
      const labelers = ctx.reqLabelers(req)
      const hydrateCtx = await ctx.hydrator.createContext({
        labelers,
        viewer,
      })
      const result = await fillPage({
        cursor: params.cursor,
        limit: params.limit,
        fetch: ({ cursor, limit }) =>
          getListsWithMembership({ ...params, cursor, limit, hydrateCtx }, ctx),
        items: (r) => r.listsWithMembership,
      })

      return {
        encoding: 'application/json',
        body: result,
        headers: resHeaders({ labelers: hydrateCtx.labelers }),
      }
    },
  })
}

const skeleton = async (
  input: SkeletonFnInput<Context, Params>,
): Promise<SkeletonState> => {
  const { ctx, params } = input
  const [actorDid] = await ctx.hydrator.actor.getDids([params.actor])
  if (!actorDid) throw new InvalidRequestError('Profile not found')

  if (clearlyBadCursor(params.cursor)) {
    return { actorDid, listUris: [] }
  }

  const { listUris, cursor } = await ctx.hydrator.dataplane.getActorLists({
    actorDid: params.hydrateCtx.viewer,
    cursor: params.cursor,
    limit: params.limit,
  })
  return {
    actorDid,
    listUris: listUris as AtUriString[],
    cursor: parseString(cursor),
  }
}

const hydration = async (
  input: HydrationFnInput<Context, Params, SkeletonState>,
) => {
  const { ctx, params, skeleton } = input
  const { actorDid, listUris } = skeleton
  return ctx.hydrator.hydrateListsMembership(
    listUris,
    actorDid,
    params.hydrateCtx,
  )
}

const filterPurposes = (
  input: RulesFnInput<Context, Params, SkeletonState>,
) => {
  const { skeleton, hydration, params } = input
  const purposes = params.purposes || ['modlist', 'curatelist']

  const acceptedPurposes = new Set()
  if (purposes.includes('modlist')) acceptedPurposes.add(MODLIST)
  if (purposes.includes(MODLIST)) acceptedPurposes.add(MODLIST)
  if (purposes.includes('curatelist')) acceptedPurposes.add(CURATELIST)
  if (purposes.includes(CURATELIST)) acceptedPurposes.add(CURATELIST)

  // Purpose filtering happens after dataplane pagination. fillPage requests
  // subsequent dataplane pages to replace lists filtered out here.
  skeleton.listUris = skeleton.listUris.filter((uri) => {
    const list = hydration.lists?.get(uri)
    return acceptedPurposes.has(list?.record.purpose)
  })
  return skeleton
}

const presentation = (
  input: PresentationFnInput<Context, Params, SkeletonState>,
) => {
  const { ctx, skeleton, hydration } = input
  const { actorDid, listUris, cursor } = skeleton
  const listsWithMembership = mapDefined(listUris, (uri) => {
    const list = ctx.views.list(uri, hydration)
    if (!list) return

    const listItemUri = hydration.listMemberships
      ?.get(uri)
      ?.get(actorDid)?.actorListItemUri

    return {
      list,
      listItem: listItemUri
        ? ctx.views.listItemView(listItemUri, actorDid, hydration)
        : undefined,
    }
  })
  return { listsWithMembership, cursor }
}

type Context = {
  hydrator: Hydrator
  views: Views
}

type Params = app.bsky.graph.getListsWithMembership.$Params & {
  hydrateCtx: HydrateCtxWithViewer
}

type SkeletonState = {
  actorDid: DidString
  listUris: AtUriString[]
  cursor?: string
}

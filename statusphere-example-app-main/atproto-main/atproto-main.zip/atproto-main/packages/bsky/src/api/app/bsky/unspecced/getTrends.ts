import { mapDefined, noUndefinedVals } from '@atproto/common'
import type { Client, DidString } from '@atproto/lex'
import { MethodNotImplementedError, type Server } from '@atproto/xrpc-server'
import type { AppContext } from '../../../../context.js'
import {
  type HydrateCtx,
  type Hydrator,
  mergeManyStates,
} from '../../../../hydration/hydrator.js'
import { app } from '../../../../lexicons/index.js'
import {
  type HydrationFn,
  type PresentationFn,
  type RulesFn,
  type SkeletonFn,
  createPipeline,
} from '../../../../pipeline.js'
import { getAtprotoPassthroughHeaders } from '../../../../util/headers.js'
import type { Views } from '../../../../views/index.js'

export default function (server: Server, ctx: AppContext) {
  const getTrends = createPipeline(skeleton, hydration, noBlocks, presentation)
  server.add(app.bsky.unspecced.getTrends, {
    auth: ctx.authVerifier.standardOptional,
    handler: async ({ auth, params, req, signal }) => {
      const viewer = auth.credentials.iss
      const labelers = ctx.reqLabelers(req)
      const hydrateCtx = await ctx.hydrator.createContext({ labelers, viewer })
      const headers = noUndefinedVals({
        'accept-language': req.headers['accept-language'],
        ...getAtprotoPassthroughHeaders(req),
      })
      const result = await getTrends(
        {
          ...params,
          hydrateCtx,
          headers,
          signal,
        },
        ctx,
      )
      return {
        encoding: 'application/json',
        body: result,
      }
    },
  })
}

const skeleton: SkeletonFn<Context, Params, SkeletonState> = async (input) => {
  const { params, ctx } = input

  if (!ctx.irisClient) {
    // Use 501 instead of 500 as these are not considered retry-able by clients
    throw new MethodNotImplementedError('Topics agent not available')
  }

  const skeleton = await ctx.irisClient.call(
    app.bsky.unspecced.getTrendsSkeleton,
    {
      limit: params.limit,
      viewer: params.hydrateCtx.viewer ?? undefined,
    },
    {
      headers: params.headers,
      signal: params.signal,
    },
  )

  // @TODO Make sure upstream always provides this
  for (const trend of skeleton.trends) trend.dids ??= []

  return skeleton
}

const hydration: HydrationFn<Context, Params, SkeletonState> = async (
  input,
) => {
  const { ctx, params, skeleton } = input
  const dids = getUniqueDidsFromTrends(skeleton.trends)
  const pairs: Map<DidString, DidString[]> = new Map()
  const viewer = params.hydrateCtx.viewer
  if (viewer) pairs.set(viewer, dids)

  const [profileState, bidirectionalBlocks] = await Promise.all([
    ctx.hydrator.hydrateProfilesBasic(dids, params.hydrateCtx),
    ctx.hydrator.hydrateBidirectionalBlocks(pairs, params.hydrateCtx),
  ])

  return mergeManyStates(profileState, { bidirectionalBlocks })
}

const noBlocks: RulesFn<Context, Params, SkeletonState> = (input) => {
  const { skeleton, params, hydration } = input
  const viewer = params.hydrateCtx.viewer
  if (!viewer) {
    return skeleton
  }

  const blocks = hydration.bidirectionalBlocks?.get(viewer)

  return {
    recIdStr: skeleton.recIdStr,
    trends: skeleton.trends.map((t) => ({
      ...t,
      dids: t.dids.filter((did) => !blocks?.get(did)),
    })),
  }
}

const presentation: PresentationFn<
  Context,
  Params,
  SkeletonState,
  app.bsky.unspecced.getTrends.$OutputBody
> = (input) => {
  const { ctx, skeleton, hydration } = input

  return {
    recIdStr: skeleton.recIdStr,
    trends: skeleton.trends.map((t) => ({
      topic: t.topic,
      displayName: t.displayName,
      description: t.description,
      link: t.link,
      startedAt: t.startedAt,
      postCount: t.postCount,
      status: t.status,
      category: t.category,
      actors: mapDefined(t.dids, (did) =>
        ctx.views.profileBasic(did, hydration),
      ),
    })),
  }
}

type Context = {
  hydrator: Hydrator
  views: Views
  irisClient: Client | undefined
}

type Params = app.bsky.unspecced.getTrendingTopics.$Params & {
  hydrateCtx: HydrateCtx & { viewer: string | null }
  headers: Record<string, string>
  signal: AbortSignal
}

type SkeletonState = app.bsky.unspecced.getTrendsSkeleton.$OutputBody

function getUniqueDidsFromTrends(
  trends?: app.bsky.unspecced.defs.SkeletonTrend[],
): DidString[] {
  if (!trends) return []

  const dids = new Set<DidString>()

  for (const trend of trends) {
    if (trend.dids) {
      for (const did of trend.dids) {
        dids.add(did)
      }
    }
  }

  return Array.from(dids)
}

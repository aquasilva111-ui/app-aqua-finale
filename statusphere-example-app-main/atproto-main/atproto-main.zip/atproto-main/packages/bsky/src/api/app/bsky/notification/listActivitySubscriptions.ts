import { mapDefined } from '@atproto/common'
import type { DidString } from '@atproto/syntax'
import type { Server } from '@atproto/xrpc-server'
import type { AppContext } from '../../../../context.js'
import type {
  HydrateCtxWithViewer,
  Hydrator,
} from '../../../../hydration/hydrator.js'
import { app } from '../../../../lexicons/index.js'
import {
  type HydrationFnInput,
  type PresentationFnInput,
  type RulesFnInput,
  type SkeletonFnInput,
  createPipeline,
} from '../../../../pipeline.js'
import type { Views } from '../../../../views/index.js'
import { clearlyBadCursor, fillPage, resHeaders } from '../../../util.js'

export default function (server: Server, ctx: AppContext) {
  const listActivitySubscriptions = createPipeline(
    skeleton,
    hydration,
    noBlocks,
    presentation,
  )
  server.add(app.bsky.notification.listActivitySubscriptions, {
    auth: ctx.authVerifier.standard,
    handler: async ({ params, auth, req }) => {
      const viewer = auth.credentials.iss
      const labelers = ctx.reqLabelers(req)
      const hydrateCtx = await ctx.hydrator.createContext({
        labelers,
        viewer,
      })

      const result = await fillPage({
        cursor: params.cursor,
        limit: params.limit,
        fetch: ({ cursor, limit }) =>
          listActivitySubscriptions(
            { ...params, cursor, limit, hydrateCtx },
            ctx,
          ),
        items: (r) => r.subscriptions,
      })

      return {
        encoding: 'application/json',
        body: result,
        headers: resHeaders({ labelers: hydrateCtx.labelers }),
      }
    },
  })
}

const skeleton = async (
  input: SkeletonFnInput<Context, Params>,
): Promise<SkeletonState> => {
  const { params, ctx } = input
  const actorDid = params.hydrateCtx.viewer
  if (clearlyBadCursor(params.cursor)) {
    return { actorDid, dids: [] }
  }
  const { dids, cursor } =
    await ctx.hydrator.dataplane.getActivitySubscriptionDids({
      actorDid: params.hydrateCtx.viewer,
      limit: params.limit,
      cursor: params.cursor,
    })
  return {
    actorDid,
    dids: dids as DidString[],
    cursor,
  }
}

const hydration = async (
  input: HydrationFnInput<Context, Params, SkeletonState>,
) => {
  const { ctx, params, skeleton } = input
  const { dids } = skeleton
  const state = await ctx.hydrator.hydrateProfilesDetailed(
    dids,
    params.hydrateCtx,
  )
  return state
}

const noBlocks = (input: RulesFnInput<Context, Params, SkeletonState>) => {
  const { skeleton, hydration, ctx } = input
  skeleton.dids = skeleton.dids.filter(
    (did) => !ctx.views.viewerBlockExists(did, hydration),
  )
  return skeleton
}

const presentation = (
  input: PresentationFnInput<Context, Params, SkeletonState>,
) => {
  const { ctx, hydration, skeleton } = input
  const { dids, cursor } = skeleton
  const subscriptions = mapDefined(dids, (did) => {
    return ctx.views.profile(did, hydration)
  })
  return { subscriptions, cursor }
}

type Context = {
  hydrator: Hydrator
  views: Views
}

type Params = app.bsky.notification.listActivitySubscriptions.$Params & {
  hydrateCtx: HydrateCtxWithViewer
}

type SkeletonState = {
  actorDid: DidString
  dids: DidString[]
  cursor?: string
}

import { dedupeStrs, mapDefined, noUndefinedVals } from '@atproto/common'
import type { Client, DidString } from '@atproto/lex'
import { MethodNotImplementedError, type Server } from '@atproto/xrpc-server'
import type { AppContext } from '../../../../context.js'
import {
  type HydrateCtx,
  type Hydrator,
  mergeManyStates,
} from '../../../../hydration/hydrator.js'
import { app } from '../../../../lexicons/index.js'
import {
  type HydrationFnInput,
  type PresentationFnInput,
  type RulesFnInput,
  type SkeletonFnInput,
  createPipeline,
} from '../../../../pipeline.js'
import { getAtprotoPassthroughHeaders } from '../../../../util/headers.js'
import type { Views } from '../../../../views/index.js'

export default function (server: Server, ctx: AppContext) {
  const getSuggestedOnboardingUsers = createPipeline(
    skeleton,
    hydration,
    noBlocksOrFollows,
    presentation,
  )
  server.add(app.bsky.unspecced.getSuggestedOnboardingUsers, {
    auth: ctx.authVerifier.standardOptional,
    handler: async ({ auth, params, req, signal }) => {
      const viewer = auth.credentials.iss
      const labelers = ctx.reqLabelers(req)
      const hydrateCtx = await ctx.hydrator.createContext({
        labelers,
        viewer,
      })
      const headers = noUndefinedVals({
        'accept-language': req.headers['accept-language'],
        ...getAtprotoPassthroughHeaders(req),
      })
      const result = await getSuggestedOnboardingUsers(
        {
          ...params,
          hydrateCtx,
          headers,
          signal,
        },
        ctx,
      )
      return {
        encoding: 'application/json',
        body: result,
      }
    },
  })
}

const skeleton = async (input: SkeletonFnInput<Context, Params>) => {
  const { params, ctx } = input
  if (!ctx.suggestionsClient) {
    throw new MethodNotImplementedError('Suggestions agent not available')
  }

  return ctx.suggestionsClient.call(
    app.bsky.unspecced.getOnboardingSuggestedUsersSkeleton,
    {
      limit: params.limit,
      viewer: params.hydrateCtx.viewer ?? undefined,
      category: params.category,
    },
    {
      headers: params.headers,
      signal: params.signal,
    },
  )
}

const hydration = async (
  input: HydrationFnInput<Context, Params, SkeletonState>,
) => {
  const { ctx, params, skeleton } = input
  const dids = dedupeStrs(skeleton.dids)
  const pairs: Map<DidString, DidString[]> = new Map()
  const viewer = params.hydrateCtx.viewer
  if (viewer) {
    pairs.set(viewer, dids)
  }
  const [profilesState, bidirectionalBlocks] = await Promise.all([
    ctx.hydrator.hydrateProfiles(dids, params.hydrateCtx),
    ctx.hydrator.hydrateBidirectionalBlocks(pairs, params.hydrateCtx),
  ])

  return mergeManyStates(profilesState, { bidirectionalBlocks })
}

const noBlocksOrFollows = (
  input: RulesFnInput<Context, Params, SkeletonState>,
) => {
  const { ctx, skeleton, params, hydration } = input
  const viewer = params.hydrateCtx.viewer
  if (!viewer) {
    return skeleton
  }
  const blocks = hydration.bidirectionalBlocks?.get(viewer)
  return {
    ...skeleton,
    dids: skeleton.dids.filter((did) => {
      const viewer = ctx.views.profileViewer(did, hydration)
      return !blocks?.get(did) && !viewer?.following
    }),
  }
}

const presentation = (
  input: PresentationFnInput<Context, Params, SkeletonState>,
) => {
  const { ctx, skeleton, hydration } = input
  return {
    recId: skeleton.recId,
    recIdStr: skeleton.recIdStr,
    actors: mapDefined(skeleton.dids, (did) =>
      ctx.views.profile(did, hydration),
    ),
  }
}

type Context = {
  hydrator: Hydrator
  views: Views
  topicsClient: Client | undefined
  suggestionsClient: Client | undefined
}

type Params = app.bsky.unspecced.getSuggestedOnboardingUsers.$Params & {
  hydrateCtx: HydrateCtx & { viewer: string | null }
  headers: Record<string, string>
  signal: AbortSignal
  category?: string
}

type SkeletonState = {
  dids: DidString[]
  recId?: string
  recIdStr?: string
}

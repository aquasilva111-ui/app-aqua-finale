import type { ServiceImpl } from '@connectrpc/connect'
import type { Service } from '../../../proto/bsky_connect.js'
import type { Database } from '../db/index.js'
import { TimeCidKeyset, paginate } from '../db/pagination.js'

export default (db: Database): Partial<ServiceImpl<typeof Service>> => ({
  async getQuotesBySubjectSorted(req) {
    const { subject, cursor, limit } = req
    const { ref } = db.db.dynamic

    if (!subject?.uri) return { uris: [] }

    let builder = db.db
      .selectFrom('quote')
      .where('quote.subject', '=', subject.uri)
      .select(['quote.uri', 'quote.cid', 'quote.sortAt'])

    const keyset = new TimeCidKeyset(ref('quote.sortAt'), ref('quote.cid'))
    builder = paginate(builder, {
      limit,
      cursor,
      keyset,
    })

    const page = keyset.page(await builder.execute(), limit)

    return {
      uris: page.items.map((q) => q.uri),
      cursor: page.cursor,
    }
  },
})

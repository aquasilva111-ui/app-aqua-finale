import React from 'react'
import Link from '@docusaurus/Link'
import BlueskyWordmark from './BlueskyWordmark'

// Bluesky butterfly halftone — concentric rings of dots faded outward from a
// body-anchored core. Geometry locked from the mockup's "pulse" lockup
// (../bps-website/prototypes/landing-bsky.html). [cx, cy, r] per dot.
const DOTS = [
  [284.0, 298.0, 16.2], [320.0, 298.0, 12.64], [309.46, 323.46, 10.75], [284.0, 334.0, 8.85],
  [258.54, 323.46, 10.75], [248.0, 298.0, 12.64], [258.54, 272.54, 10.75], [284.0, 262.0, 8.85],
  [309.46, 272.54, 10.75], [356.0, 298.0, 11.77], [346.35, 334.0, 10.89], [320.0, 360.35, 9.13],
  [284.0, 370.0, 8.24], [248.0, 360.35, 9.13], [221.65, 334.0, 10.89], [212.0, 298.0, 11.77],
  [221.65, 262.0, 10.89], [248.0, 235.65, 9.13], [320.0, 235.65, 9.13], [346.35, 262.0, 10.89],
  [392.0, 298.0, 10.9], [383.78, 339.33, 10.42], [360.37, 374.37, 9.26], [325.33, 397.78, 8.11],
  [242.67, 397.78, 8.11], [207.63, 374.37, 9.26], [184.22, 339.33, 10.42], [176.0, 298.0, 10.9],
  [184.22, 256.67, 10.42], [207.63, 221.63, 9.26], [242.67, 198.22, 8.11], [325.33, 198.22, 8.11],
  [360.37, 221.63, 9.26], [383.78, 256.67, 10.42], [428.0, 298.0, 10.0], [420.95, 342.5, 9.72],
  [400.5, 382.64, 8.97], [368.64, 414.5, 8.04], [328.5, 434.95, 7.29], [239.5, 434.95, 7.29],
  [199.36, 414.5, 8.04], [167.5, 382.64, 8.97], [147.05, 342.5, 9.72], [140.0, 298.0, 10.0],
  [147.05, 253.5, 9.72], [167.5, 213.36, 8.97], [199.36, 181.5, 8.04], [368.64, 181.5, 8.04],
  [400.5, 213.36, 8.97], [420.95, 253.5, 9.72], [464.0, 298.0, 9.1], [457.87, 344.59, 8.91],
  [439.88, 388.0, 8.41], [411.28, 425.28, 7.73], [374.0, 453.88, 7.05], [194.0, 453.88, 7.05],
  [156.72, 425.28, 7.73], [128.12, 388.0, 8.41], [110.13, 344.59, 8.91], [104.0, 298.0, 9.1],
  [110.13, 251.41, 8.91], [128.12, 208.0, 8.41], [156.72, 170.72, 7.73], [194.0, 142.12, 7.05],
  [374.0, 142.12, 7.05], [411.28, 170.72, 7.73], [439.88, 208.0, 8.41], [457.87, 251.41, 8.91],
  [478.61, 391.72, 7.71], [452.88, 432.67, 7.22], [418.67, 466.88, 6.67], [377.72, 492.61, 6.18],
  [190.28, 492.61, 6.18], [149.33, 466.88, 6.67], [115.12, 432.67, 7.22], [89.39, 391.72, 7.71],
  [73.42, 249.94, 8.05], [89.39, 204.28, 7.71], [115.12, 163.33, 7.22], [149.33, 129.12, 6.67],
  [190.28, 103.39, 6.18], [377.72, 103.39, 6.18], [418.67, 129.12, 6.67], [452.88, 163.33, 7.22],
  [478.61, 204.28, 7.71], [494.58, 249.94, 8.05], [36.84, 248.84, 7.14], [51.18, 201.56, 6.91],
  [74.47, 158.0, 6.56], [105.81, 119.81, 6.14], [144.0, 88.47, 5.73], [424.0, 88.47, 5.73],
  [462.19, 119.81, 6.14], [493.53, 158.0, 6.56], [516.82, 201.56, 6.91], [531.16, 248.84, 7.14],
  [13.37, 199.5, 6.03], [34.58, 154.0, 5.78], [63.38, 112.88, 5.48], [98.88, 77.38, 5.15],
  [144.0, 48.58, 4.85], [428.0, 48.58, 4.85], [469.12, 77.38, 5.15], [504.62, 112.88, 5.48],
  [533.42, 154.0, 5.78], [554.63, 199.5, 6.03], [21.88, 107.56, 4.7], [54.9, 68.9, 4.46],
  [93.56, 35.88, 4.21], [474.44, 35.88, 4.21], [513.1, 68.9, 4.46], [546.12, 107.56, 4.7],
  [11.93, 62.25, 3.65], [48.25, 25.93, 3.47], [519.75, 25.93, 3.47], [556.07, 62.25, 3.65],
]

function Pulse() {
  return (
    <svg
      className="bpsBrand__pulse"
      viewBox="0 0 568 501"
      fill="url(#bsky-grad)"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        {/* Dark-bar variant: light sky-blue core fading to brand blue at the
            edge (reads bright against #0d1117). */}
        <radialGradient
          id="bsky-grad"
          cx="284"
          cy="298"
          r="320"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stopColor="#7DD3FC" />
          <stop offset="1" stopColor="#0085FF" />
        </radialGradient>
        {/* Light-bar variant: deep brand blue core fading OUT to a lighter
            sky-blue at the edge — inverted from the dark variant so the dots
            stay legible against the pale #f4f6f9 bar. Switched in via CSS. */}
        <radialGradient
          id="bsky-grad-light"
          cx="284"
          cy="298"
          r="320"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stopColor="#0052CC" />
          <stop offset="1" stopColor="#4DA6FF" />
        </radialGradient>
      </defs>
      {DOTS.map(([cx, cy, r], i) => (
        <circle key={i} cx={cx} cy={cy} r={r} />
      ))}
    </svg>
  )
}

// First navbar entry: the "Bluesky Protocol Services" lockup. Link target is
// left to docusaurus.config.js (`to` or `href`); renders unlinked if neither
// is set. Returns null in the mobile sidebar — on narrow screens it stays in
// the top bar at full strength (pulse butterfly + full wordmark).
export default function BpsBrand({ mobile, to, href }) {
  if (mobile) return null
  const inner = (
    <>
      <span className="bpsBrand__pulseWrap">
        <Pulse />
      </span>
      <span className="bpsBrand__word">
        <span className="bpsBrand__full">
          <BlueskyWordmark className="bpsBrand__w1" />
          <span className="bpsBrand__w2">Protocol Services</span>
        </span>
      </span>
    </>
  )
  const cls = 'bpsNav bpsBrand'
  if (href) return <a className={cls} href={href}>{inner}</a>
  if (to) return <Link className={cls} to={to}>{inner}</Link>
  return <div className={cls}>{inner}</div>
}

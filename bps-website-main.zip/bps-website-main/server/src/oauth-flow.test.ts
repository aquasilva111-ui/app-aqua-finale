import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import type { AddressInfo } from 'node:net'
import type { DidString } from '@atproto/syntax'
import { sealData } from 'iron-session'
import { createDb, type DB } from './db/index.ts'
import { runMigrations } from './db/migrate.ts'
import { loadConfig } from './config.ts'
import { requestLocalLock } from '@atproto/oauth-client-node'
import { createOAuthClient } from './oauth/client.ts'
import { createPostgresApiKeyProvider } from './apikeys/postgres-provider.ts'
import { buildApp } from './app.ts'
import { SESSION_COOKIE_NAME } from './session/cookie.ts'

const url =
  process.env.BPS_TEST_DATABASE_URL ??
  'postgres://bps:bps@localhost:5433/bps_account'
const cfg = loadConfig({
  BPS_PORT: '8080',
  BPS_DATABASE_URL: url,
  BPS_SITE_ORIGIN: 'http://localhost:3000',
  BPS_API_ORIGIN: 'http://127.0.0.1:8080',
  BPS_COOKIE_DOMAIN: 'localhost',
  BPS_IRON_SESSION_PASSWORD: 'x'.repeat(32),
  BPS_OAUTH_HANDLE_RESOLVER: 'https://bsky.social',
  NODE_ENV: 'development',
})
const did = 'did:plc:flowtest' as DidString
let db: DB, server: any, base: string

before(async () => {
  db = createDb(url)
  await runMigrations(db)
  await db.deleteFrom('account').where('did', '=', did).execute()
  await db.insertInto('account').values({ did, email: null }).execute()
  const client = await createOAuthClient(db, cfg, requestLocalLock)
  const apiKeys = createPostgresApiKeyProvider(db)
  const app = buildApp({ db, config: cfg, client, apiKeys })
  await new Promise<void>((r) => {
    server = app.listen(0, () => {
      base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
      r()
    })
  })
})
after(async () => {
  await db.deleteFrom('account').where('did', '=', did).execute()
  await new Promise<void>((r) => server.close(() => r()))
  await db.destroy()
})

async function cookie(): Promise<string> {
  const sealed = await sealData({ did }, { password: cfg.ironSessionPassword })
  return `${SESSION_COOKIE_NAME}=${sealed}`
}

test('whoami returns 401-ish without a cookie', async () => {
  const res = await fetch(`${base}/xrpc/internal.bps.account.whoami`)
  assert.notEqual(res.status, 200)
})

test('whoami returns the did (no email when none is set) with a valid cookie', async () => {
  const res = await fetch(`${base}/xrpc/internal.bps.account.whoami`, {
    headers: { cookie: await cookie() },
  })
  assert.equal(res.status, 200)
  const json = (await res.json()) as { did: string; email?: string }
  assert.equal(json.did, did)
  // Email presence is conveyed by the field's presence — this fixture has none.
  assert.equal(json.email, undefined)
})

test('logout returns ok and an expiring Set-Cookie', async () => {
  const res = await fetch(`${base}/xrpc/internal.bps.oauth.logout`, {
    method: 'POST',
    headers: { cookie: await cookie() },
  })
  assert.equal(res.status, 200)
  const setCookie = res.headers.get('set-cookie') ?? ''
  assert.match(setCookie, new RegExp(`${SESSION_COOKIE_NAME}=`))
  assert.match(setCookie, /Max-Age=0|Expires=/i)
  const body = (await res.json()) as { ok: boolean }
  assert.deepEqual(body, { ok: true })
})
